/* MORTIS CLOUD — web-app service worker (served at /app/sw.js, scope /app/).
 *
 * The app shell is static (hashed JS/CSS under /app/assets + index.html); the
 * data layer is the API on a DIFFERENT origin (mortisia.nekuzaky.com), reached
 * over fetch/SSE with JWT auth and client-side E2E crypto.
 *
 * Strategy:
 *   - Cross-origin requests (the API, SSE, anything not on this host) → never
 *     intercepted. The SW must never touch /auth, /sync, /enc, /tokens: those
 *     are end-to-end encrypted and server-authoritative, and caching them would
 *     be both wrong and a security risk.
 *   - Same-origin shell (HTML/CSS/JS/manifest/icons) → NETWORK-FIRST: always
 *     serve the freshest build when online, fall back to cache only offline.
 *     (Cache-first would serve a stale shell after a deploy — a real bug the
 *     /m/ PWA hit; network-first avoids it.)
 */
'use strict';

const VERSION = 'v1';
const CACHE = `mortis-app-${VERSION}`;

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);

  // Only ever handle our own static shell. The API is cross-origin, so this
  // single check keeps every /auth, /sync, /enc, /tokens call untouched.
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    fetch(req)
      .then((res) => {
        // Cache successful same-origin shell responses for offline fallback.
        if (res && res.ok && res.type === 'basic') {
          const clone = res.clone();
          caches.open(CACHE).then((c) => c.put(req, clone));
        }
        return res;
      })
      .catch(() =>
        caches.match(req).then((cached) => {
          if (cached) return cached;
          // SPA navigation offline → serve the app entry so the router boots.
          if (req.mode === 'navigate') return caches.match('/app/index.html');
          return undefined;
        })
      )
  );
});
